# qlearningAgents.py
# ------------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from game import *
from learningAgents import ReinforcementAgent
from featureExtractors import *

import random, util, math


class QLearningAgentPractica(ReinforcementAgent):
    """
      Q-Learning Agent

      Functions you should fill in:
        - computeValueFromQValues
        - computeActionFromQValues
        - getQValue
        - getAction
        - update

      Instance variables you have access to
        - self.epsilon (exploration prob)
        - self.alpha (learning rate)
        - self.discount (discount rate)

      Functions you should use
        - self.getLegalActions(state)
          which returns legal actions for a state
    """

    def __init__(self, **args):
        "You can initialize Q-values here..."
        ReinforcementAgent.__init__(self, **args)

        "*** YOUR CODE HERE ***"
        """
        Debemos inicializar una tabla para guarar los QValues en la que, por defecto,
        Counter podrá todos los values a 0.0.
        """
        self.qValues = util.Counter()

    def getQValue(self, state, action):  # Return: Q(s, a)
        """
          Returns Q(state,action)
          Should return 0.0 if we have never seen a state
          or the Q node value otherwise
        """
        "*** YOUR CODE HERE ***"
        "Getter en el que, dada una acción legal, se retornará el QValue asociado"
        return self.qValues[(state, action)]

    def computeValueFromQValues(self, state):  # Return: max_a[ Q(s, a) ]
        """
          Returns max_action Q(state,action)
          where the max is over legal actions.  Note that if
          there are no legal actions, which is the case at the
          terminal state, you should return a value of 0.0.
        """
        "*** YOUR CODE HERE ***"
        """
        Primero, definimos el máximo QValue de la mejor acción como menos infinito.
        De esta forma, se actualizará con el siguiente valor que entre.
        """
        max_Qvalue = -float('inf')

        "Además, conseguiremos la lista de acciones legales (lista de tipo N,S,E,O)"
        legalActions = self.getLegalActions(state)

        "Antes de hacer nada, debemos comprobar que dicha lista de acciones no este vacia"
        if not legalActions:
            # En el caso de estarlo, retornamos 0.0 porque estamos en un estado terminal
            return 0.0
        else:
            # Si contiene alguna acción, por cada una de estas acciones legales
            for legalAction in legalActions:
                # Comprobaremos si el Q-Value de la accion legal es mayor que el maximo Q-value actual
                if self.getQValue(state, legalAction) > max_Qvalue:
                    # Si es mayor, actualizaremos el maximo Q-Value por el Q-value de la acción legal actual
                    max_Qvalue = self.getQValue(state, legalAction)

        """
        Una vez evaluadas todas las acciones legales, debemos retornar el mejor Q-Value encontrado. 
        """
        return max_Qvalue

    def computeActionFromQValues(self, state):  # Return: π(s) = a
        """
          Compute the best action to take in a state.  Note that if there
          are no legal actions, which is the case at the terminal state,
          you should return None.
        """
        "*** YOUR CODE HERE ***"

        """
        Primero, definimos el máximo Q-Value de la mejor acción como menos infinito.
        De esta forma, se actualizará con el siguiente valor que entre.
        """
        max_Qvalue = -float('inf')

        "También crearemos la lista de mejores acciones, todas con el mismo Q-value"
        best_action = []

        "Además, conseguiremos la lista de acciones legales (lista de tipo N,S,E,O)"
        legalActions = self.getLegalActions(state)

        "Antes de hacer nada, debemos comprobar que dicha lista de acciones no este vacia"
        if not legalActions:
            # En el caso de estarlo, retornamos 0.0 porque estamos en un estado terminal
            return None
        else:
            # Si contiene alguna acción, por cada una de estas acciones legales
            for legalAction in legalActions:
                # Comprobaremos si como se comporta el QValue de la accion legal actual respecto
                # al Q-value maximo encontrado hasta el momento
                actual_QValue = self.getQValue(state, legalAction)

                # En el caso de que sea mayor que el maximo Q-value
                if actual_QValue > max_Qvalue:

                    # Actualizaremos el maximo Q-Value por el Q-value de la acción legal actual
                    max_Qvalue = self.getQValue(state, legalAction)

                    # Por lo tanto, la mejor accion será la que tenga asociada este Q-value
                    best_action = [legalAction]

                # En el caso de que sea igual que el maximo actual
                elif actual_QValue == max_Qvalue:

                    # Añadiremos su acción a la lista de mejores acciones con el maximo valor de Q-Value,
                    # ya que esta accion junto con las otras de la lista son igual de buenas para escoger
                    best_action.append(legalAction)

        """
        Una vez evaluadas todas las acciones legales, deberemos retornar la mejor accion.
        Para ayudar a obtener un mejor comportamiento en la selección de acciones, utilizaremos random.choice().
        Sabiendo que todas son las mejores acciones posibles, usando random podemos propiciar el uso de acciones
        previamente no escogidas.
        """
        return random.choice(best_action)

    def getAction(self, state):  # Return: a mediante ε-voraz
        """
          Compute the action to take in the current state.  With
          probability self.epsilon, we should take a random action and
          take the best policy action otherwise.  Note that if there are
          no legal actions, which is the case at the terminal state, you
          should choose None as the action.

          HINT: You might want to use util.flipCoin(prob)
          HINT: To pick randomly from a list, use random.choice(list)
        """

        # Pick Action
        "Conseguiremos la lista de acciones legales (lista de tipo N,S,E,O)"
        legalActions = self.getLegalActions(state)
        action = None

        "*** YOUR CODE HERE ***"

        "Antes de hacer nada, debemos comprobar que dicha lista de acciones no este vacia"
        if not legalActions:
            # En el caso de estarlo, retornamos None como accion porque estamos en un estado terminal
            return action
        else:
            # Para escoger una acción de una lista, simularemos una variable binaria con probabilidad ε mediante
            # util.flipCoin(ε). En este caso, nos devolverá True con  P(ε) o False, con P(1 - ε).
            # Si la probabilidad resultante es
            if util.flipCoin(self.epsilon):
                # P(ε) (True) , significa que escogeremos una accion random
                return random.choice(legalActions)
            else:
                # P(1 - ε) (False) , significa que escogeremos la mejor Accion en funcion de los Q-Values
                return self.computeActionFromQValues(state)

    def update(self, state, action, nextState, reward):
        """
          The parent class calls this to observe a
          state = action => nextState and reward transition.
          You should do your Q-Value update here

          NOTE: You should never call this function,
          it will be called on your behalf
        """
        "*** YOUR CODE HERE ***"
        """
        Formula del Reinforcement Learning activo:
        Q(s,a) = Q(s,a) + Learning_rate (Recompensa + Descuento * max_a'[Q(s',a')] - Q(s, a))
        donde:
            - Q(s,a) es el Q-value actual 
            - Learning_rate es alfa (α)
            - Descuento es gamma (γ)
            - Recompensa es el valor que obtenemos por realizar la accion a desde el estado s
            - max_a'[Q(s',a')] es el valor maximo esperado para el siguiente estado
        """
        self.qValues[(state, action)] += self.alpha * (reward + self.discount *
                                                       self.computeValueFromQValues(nextState) -
                                                       self.getQValue(state, action))

    def getPolicy(self, state):
        return self.computeActionFromQValues(state)

    def getValue(self, state):
        return self.computeValueFromQValues(state)


"""
EXAMEN PRACTICA 3
"""


class QLearningAgent(ReinforcementAgent):
    """
      Q-Learning Agent

      Functions you should fill in:
        - computeValueFromQValues
        - computeActionFromQValues
        - getQValue
        - getAction
        - update

      Instance variables you have access to
        - self.epsilon (exploration prob)
        - self.alpha (learning rate)
        - self.discount (discount rate)

      Functions you should use
        - self.getLegalActions(state)
          which returns legal actions for a state
    """

    def __init__(self, **args):
        "You can initialize Q-values here..."
        ReinforcementAgent.__init__(self, **args)

        "*** YOUR CODE HERE ***"
        """
        Debemos inicializar una tabla para guarar los QValues en la que, por defecto,
        Counter podrá todos los values a 0.0.
        """
        self.qValues = util.Counter()

    def getQValue(self, state, action):  # Return: Q(s, a)
        """
          Returns Q(state,action)
          Should return 0.0 if we have never seen a state
          or the Q node value otherwise
        """
        "*** YOUR CODE HERE ***"
        "Getter en el que, dada una acción legal, se retornará el QValue asociado"
        return self.qValues[(state, action)]

    def computeValueFromQValues(self, state):  # Return: max_a[ Q(s, a) ]
        """
          Returns max_action Q(state,action)
          where the max is over legal actions.  Note that if
          there are no legal actions, which is the case at the
          terminal state, you should return a value of 0.0.
        """
        "*** YOUR CODE HERE ***"
        """
        Primero, definimos el máximo QValue de la mejor acción como menos infinito.
        De esta forma, se actualizará con el siguiente valor que entre.
        """
        max_Qvalue = -float('inf')

        "Además, conseguiremos la lista de acciones legales (lista de tipo N,S,E,O)"
        legalActions = self.getLegalActions(state)

        "Antes de hacer nada, debemos comprobar que dicha lista de acciones no este vacia"
        if not legalActions:
            # En el caso de estarlo, retornamos 0.0 porque estamos en un estado terminal
            return 0.0
        else:
            # Si contiene alguna acción, por cada una de estas acciones legales
            for legalAction in legalActions:
                # Comprobaremos si el Q-Value de la accion legal es mayor que el maximo Q-value actual
                if self.getQValue(state, legalAction) > max_Qvalue:
                    # Si es mayor, actualizaremos el maximo Q-Value por el Q-value de la acción legal actual
                    max_Qvalue = self.getQValue(state, legalAction)

        """
        Una vez evaluadas todas las acciones legales, debemos retornar el mejor Q-Value encontrado. 
        """
        return max_Qvalue

    def computeActionFromQValues(self, state):  # Return: π(s) = a
        """
          Compute the best action to take in a state.  Note that if there
          are no legal actions, which is the case at the terminal state,
          you should return None.
        """
        "*** YOUR CODE HERE ***"

        """
        Primero, definimos el máximo Q-Value de la mejor acción como menos infinito.
        De esta forma, se actualizará con el siguiente valor que entre.
        """
        max_Qvalue = -float('inf')

        "También crearemos la lista de mejores acciones, todas con el mismo Q-value"
        best_action = []

        "Además, conseguiremos la lista de acciones legales (lista de tipo N,S,E,O)"
        legalActions = self.getLegalActions(state)

        "Antes de hacer nada, debemos comprobar que dicha lista de acciones no este vacia"
        if not legalActions:
            # En el caso de estarlo, retornamos 0.0 porque estamos en un estado terminal
            return None
        else:
            # Si contiene alguna acción, por cada una de estas acciones legales
            for legalAction in legalActions:
                # Comprobaremos si como se comporta el QValue de la accion legal actual respecto
                # al Q-value maximo encontrado hasta el momento
                actual_QValue = self.getQValue(state, legalAction)

                # En el caso de que sea mayor que el maximo Q-value
                if actual_QValue > max_Qvalue:

                    # Actualizaremos el maximo Q-Value por el Q-value de la acción legal actual
                    max_Qvalue = self.getQValue(state, legalAction)

                    # Por lo tanto, la mejor accion será la que tenga asociada este Q-value
                    best_action = [legalAction]

                # En el caso de que sea igual que el maximo actual
                elif actual_QValue == max_Qvalue:

                    # Añadiremos su acción a la lista de mejores acciones con el maximo valor de Q-Value,
                    # ya que esta accion junto con las otras de la lista son igual de buenas para escoger
                    best_action.append(legalAction)

        """
        Una vez evaluadas todas las acciones legales, deberemos retornar la mejor accion.
        Para ayudar a obtener un mejor comportamiento en la selección de acciones, utilizaremos random.choice().
        Sabiendo que todas son las mejores acciones posibles, usando random podemos propiciar el uso de acciones
        previamente no escogidas.
        """
        return random.choice(best_action)

    def softmax(self, state):
        """Primero inicializamos la lista de resultados de la función softmax para nuestro estado y cada acción legal"""
        softmax_list = []

        "Ademas conseguiremos la lista de acciones legales (lista de tipo N,S,E,O)"
        legalActions = self.getLegalActions(state)

        "Antes de hacer nada, debemos comprobar que dicha lista de acciones no este vacia"
        if not legalActions:
            # En el caso de estarlo, retornamos [] porque estamos en un estado terminal
            return softmax_list
        else:
            # Si contiene alguna acción, debemos calcular el denominador de la funcion y luego la funcion de
            # Softmax para cada una de las acciones legales
            # Primero sacamos el denominador como el sumatorio de todas las exponenciales en funcion del total
            # de acciones legales
            denominador = sum(
                [pow(math.e, self.getQValue(state, legalAction) / self.temperature_softmax) for legalAction in
                 legalActions])

            # Luego por cada accion legal,
            for legalAction in legalActions:
                # Calculamos la exponencial en funcion de dicha accion legal
                numerador = pow(math.e, self.getQValue(state, legalAction) / self.temperature_softmax)

                # Calculamos la función de softmax actual
                softmax = numerador / denominador

                # Por ultimo, añadimos a la lista la funcion calculada
                softmax_list.append(softmax)

        "Finalmente, devolvemos todas las funciones de softmax en una lista"
        return softmax_list

    def getAction(self, state):  # Return: a mediante ε-greedy + softmax
        """
          Compute the action to take in the current state.  With
          probability self.epsilon, we should take a random action and
          take the best policy action otherwise.  Note that if there are
          no legal actions, which is the case at the terminal state, you
          should choose None as the action.

          HINT: You might want to use util.flipCoin(prob)
          HINT: To pick randomly from a list, use random.choice(list)
        """

        # Pick Action
        "Conseguiremos la lista de acciones legales (lista de tipo N,S,E,O)"
        legalActions = self.getLegalActions(state)
        action = None

        "Además, también conseguimos la lista de funciones softmax para este estado"
        softmaxList = self.softmax(state)

        "*** YOUR CODE HERE ***"

        "Antes de hacer nada, debemos comprobar que dicha lista de acciones no este vacia"
        if not legalActions:
            # En el caso de estarlo, retornamos None como accion porque estamos en un estado terminal
            return action
        else:
            # Para escoger una acción de una lista, simularemos una variable binaria con probabilidad ε mediante
            # util.flipCoin(ε). En este caso, nos devolverá True con  P(ε) o False, con P(1 - ε).
            # Si la probabilidad resultante es
            if util.flipCoin(self.epsilon):
                # P(ε) (True), significa que escogeremos una accion random
                return random.choice(legalActions)
            else:
                # P(1 - ε) (False), significa que debemos generar otro numero aleatorio y comprobar entre que valores
                # se encuentra para devolver la accion pertinente
                random_value = random.random()

                # Primero establecemos los extremos entre los que evaluaremos dicho numero: [minimum,maximum]
                minimum, maximum = 0, softmaxList[0]

                # Como sabemos, hay tantas funciones de softmax como acciones legales hay para este estado.
                # Por lo tanto, por cada indice posible en la longitud de la lista de funciones softmax
                idx = 0
                for idx in range(len(softmaxList)):

                    # Primero comprobaremos si nuestro valor aleatorio se encuentra en el intervalo actual
                    if minimum < random_value < maximum:
                        # El el caso de cumplirse, devolveremos la accion legal en la misma
                        # posicion en la que hemos guardado su funcion de softmax
                        return legalActions[idx]

                    else:
                        # Sino, actualizamos el extremo inferior con la funcion de softmax actual
                        minimum += softmaxList[idx]
                        # y el extremo superior con la siguinte funcion de softmax
                        maximum += softmaxList[idx + 1]

    def update(self, state, action, nextState, reward):
        """
          The parent class calls this to observe a
          state = action => nextState and reward transition.
          You should do your Q-Value update here

          NOTE: You should never call this function,
          it will be called on your behalf
        """
        "*** YOUR CODE HERE ***"
        """
        Formula del Reinforcement Learning activo:
        Q(s,a) = Q(s,a) + Learning_rate (Recompensa + Descuento * max_a'[Q(s',a')] - Q(s, a))
        donde:
            - Q(s,a) es el Q-value actual 
            - Learning_rate es alfa (α)
            - Descuento es gamma (γ)
            - Recompensa es el valor que obtenemos por realizar la accion a desde el estado s
            - max_a'[Q(s',a')] es el valor maximo esperado para el siguiente estado
        """
        self.qValues[(state, action)] += self.alpha * (reward + self.discount *
                                                       self.computeValueFromQValues(nextState) -
                                                       self.getQValue(state, action))

    def getPolicy(self, state):
        return self.computeActionFromQValues(state)

    def getValue(self, state):
        return self.computeValueFromQValues(state)


class PacmanQAgent(QLearningAgent):
    "Exactly the same as QLearningAgent, but with different default parameters"

    def __init__(self, epsilon=0.05, gamma=0.8, alpha=0.2, numTraining=0, **args):
        """
        These default parameters can be changed from the pacman.py command line.
        For example, to change the exploration rate, try:
            python pacman.py -p PacmanQLearningAgent -a epsilon=0.1

        alpha    - learning rate
        epsilon  - exploration rate
        gamma    - discount factor
        numTraining - number of training episodes, i.e. no learning after these many episodes
        """
        args['epsilon'] = epsilon
        args['gamma'] = gamma
        args['alpha'] = alpha
        args['numTraining'] = numTraining
        self.index = 0  # This is always Pacman
        QLearningAgent.__init__(self, **args)

    def getAction(self, state):
        """
        Simply calls the getAction method of QLearningAgent and then
        informs parent of action for Pacman.  Do not change or remove this
        method.
        """
        action = QLearningAgent.getAction(self, state)
        self.doAction(state, action)
        return action


class ApproximateQAgent(PacmanQAgent):
    """
       ApproximateQLearningAgent

       You should only have to overwrite getQValue
       and update.  All other QLearningAgent functions
       should work as is.
    """

    def __init__(self, extractor='IdentityExtractor', **args):
        self.featExtractor = util.lookup(extractor, globals())()
        PacmanQAgent.__init__(self, **args)
        self.weights = util.Counter()

    def getWeights(self):
        return self.weights

    def getQValue(self, state, action):
        """
          Should return Q(state,action) = w * featureVector
          where * is the dotProduct operator
        """
        "*** YOUR CODE HERE ***"
        util.raiseNotDefined()

    def update(self, state, action, nextState, reward):
        """
           Should update your weights based on transition
        """
        "*** YOUR CODE HERE ***"
        util.raiseNotDefined()

    def final(self, state):
        "Called at the end of each game."
        # call the super-class final method
        PacmanQAgent.final(self, state)

        # did we finish training?
        if self.episodesSoFar == self.numTraining:
            # you might want to print your weights here for debugging
            "*** YOUR CODE HERE ***"
            pass
