# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util


class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return [s, s, w, s, w, w, s, w]


def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print("Start:", problem.getStartState())
    print("Is the start a goal?", problem.isGoalState(problem.getStartState()))
    print("Start's successors:", problem.getSuccessors(problem.getStartState()))

    """
    "*** YOUR CODE HERE ***"

    " Definimos la pila para los posibles estados, junto con la lista de los estados ya visitados. "
    estados_visitados = []
    pila = util.Stack()

    " Para empezar, debemos añadir el estado inicial a la pila para ver los "
    " posibles siguientes estados a este y estudiarlos. "
    pila.push((problem.getStartState(), []))  # Primer estado de la pila: estado inicial sin acciones hechas

    " Estudiaremos los estados del mapa hasta llegar al estado Final (Goal), "
    " mientras la pila contenga algún par (estado, acciones) "
    while not pila.isEmpty():
        # Cogemos el último par añadido y marcamos dicho estado/posicion como visto
        estado, acciones = pila.pop()
        estados_visitados.append(estado)

        # Comprobamos si hemos alcanzado nuestra meta
        if problem.isGoalState(estado):
            return acciones

        # En el caso contrario, estudiaremos sus estados hijos o sucesores
        for estado_siguiente, direccion, coste in problem.getSuccessors(estado):
            if estado_siguiente not in estados_visitados:               # de los cuales solo nos centraremos en los
                pila.push((estado_siguiente, acciones + [direccion]))   # no contemplados y los añadiremos a la pila
                                                                        # para la siguiente iteración

    util.raiseNotDefined()


def breadthFirstSearch(problem):
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"

    " Definimos la cola para los posibles estados, junto con la lista de los estados ya visitados. "
    estados_visitados = []
    cola = util.Queue()

    " Para empezar, añadiremos a la cola el estado inicial sin acciones previamente realizadas. "
    cola.push((problem.getStartState(), []))

    " Estudiaremos los estados del mapa hasta llegar al estado Final (Goal) "
    while not cola.isEmpty():
        # Cogemos el primer par añadido
        estado, acciones = cola.pop()

        # Si el estado no ha sido visitado previamente, lo estudiaremos
        # En el caso de ya haber sido visitado, pasaremos al siguiente
        if estado not in estados_visitados:
            # Actualizamos los estados visitados por el pacman
            estados_visitados.append(estado)

            # Luego comprobamos si es el estado final
            if problem.isGoalState(estado):
                return acciones

            # Si no lo es, añadiremos a la cola sus estados hijos o sucesores
            for estado_siguiente, direccion, coste in problem.getSuccessors(estado):
                cola.push((estado_siguiente, acciones + [direccion]))

    util.raiseNotDefined()


def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    util.raiseNotDefined()


def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0


def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"

    " Definimos la cola para los posibles estados a visitar junto con la lista de "
    " los estados ya visitados. "
    estados_visitados = []
    cola_star = util.PriorityQueue()

    " Para empezar, deberemos añadir el estado inicial a la pila, junto con la función "
    " de evaluación f(n) = h(n), ya que el coste del estado inicial es g(n) = 0 "
    cola_star.push((problem.getStartState(), []), heuristic(problem.getStartState(), problem))

    " Estudiaremos los estados del mapa hasta llegar al estado Final (Goal), "
    " mientras la cola contenga algún elemento "
    while not cola_star.isEmpty():
        # Cogemos el primer par añadido
        estado, acciones = cola_star.pop()

        # Comprobamos si hemos alcanzado nuestra meta
        if problem.isGoalState(estado):
            return acciones

        # En caso contrario, si el estado no ha sido visitado,
        if estado not in estados_visitados:
            # marcaremos dicho estado como visto
            estados_visitados.append(estado)

            # Para cada uno de los sucesores del estado/posición
            for estado_siguiente, direccion, coste in problem.getSuccessors(estado):
                # Calcularemos su coste por las acciones realizadas
                coste_siguiente = problem.getCostOfActions(acciones + [direccion])\
                                  + heuristic(estado_siguiente, problem)

                # y las actualizaremos si es necesario
                if estado_siguiente not in estados_visitados:
                    cola_star.update((estado_siguiente, acciones + [direccion]), coste_siguiente)

    util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
