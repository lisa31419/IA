# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent


class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """

    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices)  # Pick randomly among the best

        "Add more of your code here if you want to"
        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"

        "Primero definiremos algunas variables, como la minima distancia hacia la comida más cercana"
        minFoodDist = float("inf")

        "Luego, la lista de con los estados actuales de la comida"
        foodList = currentGameState.getFood().asList()

        "Ahora, por cada estado de comida de la lista de estados actuales de comida"
        for food in foodList:
            # Calcularemos la distancia de Manhattan entre la posicion del Pacman y la comida
            distancia = manhattanDistance(newPos, food)
            # Si esta nueva distancia es menor que la minima establecida, actualizamos la distancia minima
            minFoodDist = min(distancia, minFoodDist)

        "Por cada estado de los estados de los fantasmas"
        for state in newGhostStates:
            # Si la posicion del fantasma y nuestro siguiente movimiento son iguales,
            # ademas de que el fantasma no esta asustado, estaremos a un movimiento de perder
            if state.getPosition() == newPos and state.scaredTimer == 0:
                # Para evitar este movimiento le asignamos el valor - infinito
                # Así no considerara esta accion
                return float("-inf")

        "Finalmente, devolvemos la minima distancia que hay hasta la comida más cercana"
        "Será negativa por ser la distancia que nos falta hasta llegar a dicha comida"
        return -1 * minFoodDist


def scoreEvaluationFunction(currentGameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return currentGameState.getScore()


class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """

    def __init__(self, evalFn='scoreEvaluationFunction', depth='2'):
        self.index = 0  # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

    """
    Inicializador para el examen. En este caso, deberemos añadir un parametro extra: kParam.
    Este valor será usado para calcular el minValue de la clase expectimaxMinimaxAgent1. 
    """
    def __init__(self, evalFn='scoreEvaluationFunction', depth='3', kParam='0.5'):
        self.index = 0  # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)
        self.kParam = float(kParam)

class MinimaxAgent(MultiAgentSearchAgent):
    """
    Your minimax agent (question 2)
    """

    def getAction(self, gameState):  # minimax function
        """
        Returns the minimax action from the current gameState using self.depth
        and self.evaluationFunction.

        Here are some method calls that might be useful when implementing minimax.

        gameState.getLegalActions(agentIndex):
        Returns a list of legal actions for an agent
        agentIndex=0 means Pacman, ghosts are >= 1

        gameState.generateSuccessor(agentIndex, action):
        Returns the successor game state after an agent takes an action

        gameState.getNumAgents():
        Returns the total number of agents in the game

        gameState.isWin():
        Returns whether or not the game state is a winning state

        gameState.isLose():
        Returns whether or not the game state is a losing state
        """
        "*** YOUR CODE HERE ***"

        def minValue(state, depth, agentIndex):  # GHOSTS FUNCTION
            "Primero, definimos el número de agentes de la funcion, que serán fantasmas"
            agentCount = gameState.getNumAgents()
            "Además, también conseguiremos su lista de acciones legales (lista de tipo N,S,E,O)"
            legalActions = state.getLegalActions(agentIndex)

            '''
            Antes de profundiar en la función minValue, haremos 2 comprobaciones. Primero, comprobaremos que la lista de 
            acciones legales no esté vacía. Luego miraremos si hemos perdido el juego según su estado.
            En el caso de que alguna sea cierta o las 2, retornaremos la evalución del estado.
            '''
            if legalActions == [] or gameState.isLose():
                return self.evaluationFunction(state)

            '''
            En el caso de que sigamos jugando, calcularemos la mejor jugada para cada fantasma del juego.
            Para ello, mientras queden fantasmas, es decir, mientras no sea el turno del pacman   
            '''
            if agentIndex != agentCount - 1:
                # Por cada accion legal de los fantasmas, llamaremos recursivamente a minValue hasta quedarnos con el
                # minimo valor de todos los posibles, ya que esta es la jugada que favorecerá más a los fantasmas.
                minimumValue = min(
                    minValue(state.generateSuccessor(agentIndex, legalAction), depth, agentIndex + 1) for legalAction in
                    legalActions)

            else:
                # En este caso, ya no quedan fantasmas y le toca al Pacman. Al Pacman le interesa maximizar sus ganancias,
                # por ello llamaremos recursivamente a maxValue por cada accion legal que puedan hacer los fantasmas.
                # Como, de todas las posibles jugadas del Pacman, a los fantasmas les interesa la que minimice sus
                # ganancias, pillaremos el minimo valor posible de las jugadas del Pacman ante las acciones de los fantasmas.
                minimumValue = min(
                    maxValue(state.generateSuccessor(agentIndex, legalAction), depth, 0) for legalAction in
                    legalActions)

            "Una vez hechos todos los calculos en profundidad, retornaremos la mejor accion para los fantasmas"
            return minimumValue

        def maxValue(state, depth, agentIndex):  # PACMAN FUNCTION
            """
            Como en este caso nuestro agente es el Pacman y solo hay uno, no necesitamos saber el numero de agentes
            Sin embargo, si queremos conocer su listado de acciones legales
            """
            legalActions = state.getLegalActions(agentIndex)

            '''
            Antes de profundiar en la función maxValue, haremos comprobaciones. Primero, comprobaremos que la lista de 
            acciones legales no esté vacía. Luego miraremos si hemos alcanzado la profundidad maxima o si hemos ganado
            el juego según su estado. En el caso de que alguna sea cierta, retornaremos la evalución del estado.
            '''
            if legalActions == [] or depth == self.depth or gameState.isWin():
                return self.evaluationFunction(state)

            '''
            A nuestro Pacman lo que le interesa es maximizar sus ganancias respecto a los fantasmas, por lo que por
            cada accion legal posible que tenga, comprobará las jugadas de los fantasmas en esos casos.
            De todas estas posiblidades, escogerá la que mayor beneficio le traiga.
            '''
            maximumValue = max(
                minValue(state.generateSuccessor(agentIndex, legalAction), depth + 1, agentIndex + 1) for legalAction in
                legalActions)

            "Una vez conseguida la mejor jugada del Pacman para este estado, retornaremos dicho valor"
            return maximumValue

        def minimax(state, depth, agentIndex):
            "Primero definimos la mejor evaluación y la mejor accion"
            bestActionEval, bestAction = - float("inf"), None

            "Luego, conseguimos la lista de acciones legales del agente"
            legalActions = state.getLegalActions(agentIndex)

            "Por cada accion legal del agente"
            for legalAction in legalActions:
                # Evaluaremos cual será la mejor jugada de su openente respecto a esta accion
                evalAction = minValue(gameState.generateSuccessor(agentIndex, legalAction), depth, agentIndex + 1)

                # Si la jugada evaluada actualmente es mejor que la mejor evaluacion registrada
                if evalAction > bestActionEval:
                    # Actualizaremos la mejor evaluación y la mejor jugada por las actuales
                    bestActionEval = evalAction
                    bestAction = legalAction

            "Una vez llegado el final del juego, retornaremos la mejor accion dado un juego  perfecto por ambas partes"
            return bestAction

        "Como empezará a moverse el Pacman maximizando, asignaremos el index del agente a 0"
        agentIndex = 0
        return minimax(gameState, 1, agentIndex)


class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"

        def minValue_alpha_beta(state, depth, agentIndex, alpha, beta):  # GHOSTS FUNCTION
            "Primero, definimos el número de agentes de la funcion, que serán fantasmas"
            agentCount = gameState.getNumAgents()

            "Además, también conseguiremos su lista de acciones legales (lista de tipo N,S,E,O)"
            legalActions = state.getLegalActions(agentIndex)

            "También definimos el valor minimo como infinito"
            minimumValue, currentBeta = float("inf"), beta

            '''
            Antes de profundizar en la función minValue_alpha_beta, haremos 2 comprobaciones. Primero, comprobaremos que
            la lista de acciones legales no esté vacía. Luego miraremos si hemos perdido el juego según su estado.
            En el caso de que alguna sea cierta o las 2, retornaremos la evalución del estado.
            '''
            if legalActions == [] or gameState.isLose():
                return self.evaluationFunction(state)

            '''
            En el caso de que sigamos jugando, calcularemosmos la mejor jugada para cada fantasma del juego.
            Para ello, mientras queden fantasmas, es decir, mientras no sea el turno del pacman   
            '''
            if agentIndex != agentCount - 1:
                # Por cada accion legal de los fantasmas, llamaremos recursivamente a minValue_alpha_beta hasta
                # quedarnos con el minimo valor entre el valor minimo actual y todos los posibles de la función,
                # ya que esta es la jugada que favorecerá más a los fantasmas mediante la poda.
                for legalAction in legalActions:
                    minimumValue = min(minimumValue,
                                       minValue_alpha_beta(state.generateSuccessor(agentIndex, legalAction), depth,
                                                           agentIndex + 1, alpha, currentBeta))

                    # En caso de que alfa sea mejor que nuestro valor minimo
                    if minimumValue < alpha:
                        # retornamos el valor minimo
                        return minimumValue

                    # En caso contrario, actualizamos nuestra beta actual con el minimo valor entre
                    # nuestra beta actual y el minimo valor obtenido
                    currentBeta = min(beta, minimumValue)

            else:
                # En este caso, ya no quedan fantasmas y le toca al Pacman. Al Pacman le interesa maximizar sus
                # ganancias, por ello llamaremos recursivamente a maxValue_alpha_beta por cada accion legal que puedan
                # hacer los fantasmas.
                # Como, de todas las posibles jugadas del Pacman, a los fantasmas les interesa la que minimice sus
                # ganancias, pillaremos el minimo valor posible entre las jugadas del Pacman y el valor minimo actual
                # ante las acciones de los fantasmas siguiendo la poda.
                for action in legalActions:
                    minimumValue = min(minimumValue,
                                       maxValue_alpha_beta(state.generateSuccessor(agentIndex, action), depth, 0, alpha,
                                                           currentBeta))
                    # En caso de que alfa sea mejor que nuestro valor minimo
                    if minimumValue < alpha:
                        # retornamos el valor minimo
                        return minimumValue

                    # En caso contrario, actualizamos nuestra beta actual con el minimo valor entre
                    # nuestra beta actual y el minimo valor obtenido
                    currentBeta = min(beta, minimumValue)

            "Una vez hechos todos los calculos en profundidad, retornaremos la mejor accion para los fantasmas"
            return minimumValue

        def maxValue_alpha_beta(state, depth, agentIndex, alpha, beta):  # PACMAN FUNCTION
            """
            Como en este caso nuestro agente es el Pacman y solo hay uno, no necesitamos saber el numero de agentes
            Sin embargo, sí queremos conocer su listado de acciones legales
            """
            legalActions = state.getLegalActions(agentIndex)

            "También definimos el valor máximo como -infinito y la alfa actual"
            maximumValue, currentAlpha = - float("inf"), alpha

            '''
            Antes de profundiar en la función maxValue_alpha_beta, haremos comprobaciones. Primero, comprobaremos que la
            lista de acciones legales no esté vacía. Luego miraremos si hemos alcanzado la profundidad maxima o si hemos
            ganado el juego según su estado. En el caso de que alguna sea cierta, retornaremos la evalución del estado.
            '''
            if legalActions == [] or depth == self.depth or gameState.isWin():
                return self.evaluationFunction(state)

            '''
            A nuestro Pacman lo que le interesa es maximizar sus ganancias respecto a los fantasmas, por lo que por
            cada accion legal posible que tenga, comprobará que le interesa más entre las jugadas de los fantasmas en 
            esos casos y su valor maximo actual. De todas estas posiblidades, escogerá la que mayor beneficio le traiga.
            '''
            for legalAction in legalActions:
                maximumValue = max(maximumValue,
                                   minValue_alpha_beta(state.generateSuccessor(agentIndex, legalAction), depth + 1,
                                                       agentIndex + 1, currentAlpha, beta))
                # En caso de que beta sea peor que nuestro valor maximo
                if maximumValue > beta:
                    # retornamos el valor maximo
                    return maximumValue
                # En caso contrario, actualizamos alpha con el maximo entre si misma y el valor maximo actual
                currentAlpha = max(alpha, maximumValue)

            "Una vez conseguida la mejor jugada del Pacman para este estado, retornaremos dicho valor"
            return maximumValue

        def alpha_beta_pruning(state, depth, agentIndex, alpha, beta):
            "Primero definimos la mejor evaluación y la mejor accion"
            bestActionEval, bestAction = - float("inf"), None

            "Luego, conseguimos la lista de acciones legales del agente"
            legalActions = state.getLegalActions(agentIndex)

            "Por cada accion legal del agente"
            for legalAction in legalActions:
                # Evaluaremos cual será la mejor jugada de su openente respecto a esta accion
                evalAction = minValue_alpha_beta(gameState.generateSuccessor(agentIndex, legalAction), depth,
                                                 agentIndex + 1, alpha, beta)

                # Si la jugada evaluada actualmente es mejor que la mejor evaluacion registrada
                if evalAction > bestActionEval:
                    # Actualizaremos la mejor evaluación y la mejor jugada por las actuales
                    bestActionEval = evalAction
                    bestAction = legalAction

                # Si la jugada evaluada actualmente es mejor que nuestra beta
                if evalAction > beta:
                    # retornamos la accion legal actual del agente
                    return legalAction

                # En caso contrario, actualizamos nuestra alfa con el maximo entre la jugada evaluada y el propio alfa
                alpha = max(evalAction, alpha)

            "Una vez llegado el final del juego, retornaremos la mejor accion dado un juego  perfecto por ambas partes"
            return bestAction

        "Como empezará a moverse el Pacman maximizando, asignaremos el index del agente a 0"
        agentIndex = 0

        "Ademas, debemos inicializar alfa y beta para inciar el algoritmo de poda"
        alpha, beta = - float("inf"), float("inf")

        return alpha_beta_pruning(gameState, 1, agentIndex, alpha, beta)


class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
        Returns the expectimax action using self.depth and self.evaluationFunction

        All ghosts should be modeled as choosing uniformly at random from their
        legal moves.
        """
        "*** YOUR CODE HERE ***"

        def probabilityValue(state, depth, agentIndex):
            "Primero, definimos el número de agentes de la funcion, que serán fantasmas"
            agentCount = gameState.getNumAgents()

            "Además, también conseguiremos su lista de acciones legales (lista de tipo N,S,E,O)"
            legalActions = state.getLegalActions(agentIndex)

            '''
            Antes de profundizar en la función probabilityValue, haremos 2 comprobaciones. Primero, comprobaremos que
            la lista de acciones legales no esté vacía. Luego miraremos si hemos perdido el juego según su estado.
            En el caso de que alguna sea cierta o las 2, retornaremos la evalución del estado.
            '''
            if legalActions == [] or gameState.isLose():
                return self.evaluationFunction(state)

            '''
            Como estamos jugando con probabilidades, de forma trivial, sabiendo que tenemos n acciones legales,
            nuestra probabilidad de escoger alguna de dichas acciones es 1/numero de acciones legales disponibles.
            '''
            probability = 1.0 / len(legalActions)

            "Inicializaremos el valor de espectimax que buscamos"
            espectimaxValue = 0

            "Por cada accion legal de los fantasmas"
            for legalAction in legalActions:
                # Mientras queden fantasmas, es decir, mientras no sea el turno del pacman
                if agentIndex != agentCount - 1:
                    # Llamaremos a probabilityValue para quedarnos con el valor de espectimax de la acción actual
                    currentExpectimaxValue = probabilityValue(state.generateSuccessor(agentIndex, legalAction), depth,
                                                              agentIndex + 1)
                else:
                    # En este caso, ya no quedan fantasmas y le toca al Pacman. Al Pacman le interesa maximizar sus
                    # ganancias, por ello llamaremos a maxValue_expectimax con la accion legal actual
                    currentExpectimaxValue = maxValue_expectimax(state.generateSuccessor(agentIndex, legalAction),
                                                                 depth, 0)

                # El valor resultante será la muliplicación del valor calculado por la probabilidad de que escoja
                # esa accion el fantasma
                espectimaxValue += currentExpectimaxValue * probability

            "Una vez hechos todos los calculos en profundidad, retornaremos el valor resultante"
            return espectimaxValue

        def maxValue_expectimax(state, depth, agentIndex):
            """
            Como en este caso nuestro agente es el Pacman y solo hay uno, no necesitamos saber el numero de agentes
            Sin embargo, sí queremos conocer su listado de acciones legales
            """
            legalActions = state.getLegalActions(agentIndex)

            "También definimos el valor maximo como -infinito"
            maximumValue = - float("inf")

            '''
            Antes de profundiar en la función maxValue_expectimax, haremos comprobaciones. Primero, comprobaremos que la
            lista de acciones legales no esté vacía. Luego miraremos si hemos alcanzado la profundidad maxima o si hemos
            ganado el juego según su estado. En el caso de que alguna sea cierta, retornaremos la evalución del estado.
            '''
            if legalActions == [] or depth == self.depth or gameState.isWin():
                return self.evaluationFunction(state)

            '''
            A nuestro Pacman lo que le interesa es maximizar sus ganancias respecto a los fantasmas, por lo que por
            cada accion legal posible que tenga, comprobará que le interesa más entre las jugadas de los fantasmas en 
            esos casos y su valor maximo actual. De todas estas posibilidades, escogerá la que mayor beneficio le traiga.
            '''
            for legalAction in legalActions:
                maximumValue = max(maximumValue, probabilityValue(state.generateSuccessor(agentIndex, legalAction),
                                                                  depth + 1, agentIndex + 1))

            "Una vez conseguida la mejor jugada del Pacman para este estado, retornaremos dicho valor"
            return maximumValue

        def espectimax(state, depth, agentIndex):
            "Primero definimos la mejor evaluación y la mejor accion"
            bestActionEval, bestAction = - float("inf"), None

            "Luego, conseguimos la lista de acciones legales del agente"
            legalActions = state.getLegalActions(agentIndex)

            "Por cada accion legal del agente"
            for legalAction in legalActions:
                # Evaluaremos cual será la mejor jugada de su openente respecto a esta accion
                evalAction = probabilityValue(gameState.generateSuccessor(agentIndex, legalAction), depth,
                                              agentIndex + 1)

                # Si la jugada evaluada actualmente es mejor que la mejor evaluacion registrada
                if evalAction > bestActionEval:
                    # Actualizaremos la mejor evaluación y la mejor jugada por las actuales
                    bestAction = legalAction
                    bestActionEval = evalAction

            "Una vez llegado el final del juego, retornaremos la mejor accion"
            return bestAction

        "Como empezará a moverse el Pacman, asignaremos el index del agente a 0"
        agentIndex = 0
        return espectimax(gameState, 1, agentIndex)


def betterEvaluationFunction(currentGameState):
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).

    DESCRIPTION: En esta función valoraremos los estados del Pacman, del fantasma y de toda la comida
    para calcular un score proporcional e instar al Pacman a comerse la comida y a algún fantasma por el
    camino. De esta forma conseguiremos llegar a +1000 puntos.
    """
    "*** YOUR CODE HERE ***"

    """
    Como nuestro objetivo es centrarnos en los estados y no las acciones, deberemos tener en cuenta 3 parametros:
    donde está la comida, donde están los fantansamas o el fantasma y donde está nuestro Pacman.
    Por ende, definiremos el estado actual de cada uno. 
    """
    foodList = currentGameState.getFood().asList()
    ghosts = currentGameState.getGhostStates()
    pacmanPosition = currentGameState.getPacmanPosition()

    "También inicializaremos el valor final que tendremos al terminar la partida"
    score = 0

    """
    Nuestra mejor opción para ganar es usar una buena heurística y la que mejores resultados nos ha dado
    es la distancia de Manhattan. Por lo tanto, necesitamos saber a que distancia tenemos la comida y a que
    distancia esta el fantasma o fantasmas
    """
    distanceToFood = [manhattanDistance(pacmanPosition, food) for food in foodList]
    distanceToGhosts = [manhattanDistance(pacmanPosition, ghost.getPosition()) for ghost in ghosts]

    """
    Cuanta más comida nos falte por comer, peor será la posición del Pacman. En otras palabras, debemos penalizar 
    que quede demasiada comida en el mapa para que se dé prisa en comerla.
    Por ello, conseguiremos el score actual y le restaremos 2 veces la cantidad de comida restante como penalización.
    """
    score += currentGameState.getScore() - 2 * len(foodList)

    """
    Ahora debemos analizar como de lejos estamos de toda la comida restante. Es decir, por cada comida que quede en el
    mapa, debemos penalizar dicha distancia en el score.
    """
    for food in distanceToFood:
        score -= food

    """
    Los fantasmas debemos evitarlos a toda costa (a menos que podamos comernoslos) ya que nos pueden hacer perder
    la partida. Por ello, por cada fantasma que haya (en este caso solo uno, pero se entiende que en otros mapas
    pueden haber más de uno), estudiaremos su posición y como penalizar dicha distancia hacia el Pacman. 
    """
    for ghost in distanceToGhosts:
        # Si la distancia hacia nuestro fantasma es menor que el numero de distancias que hay a evaluar,
        # debemos penalizarlo estoicamente ya que quiere decir que el Pacman tiene al fantasma encima.
        if ghost < len(distanceToGhosts):
            score += - float("inf")
        else:
            # En caso contrario, solo penalizaremos 5 veces la distancia hacia el fantasma
            score -= 5 * ghost

    "Una vez hechos todos los calculos, devolvemos el valor resultante"
    return score


class expectimaxMinimaxAgent1(MultiAgentSearchAgent):
    """
      Your expectimax + minimax agent (exam question)
    """

    def getAction(self, gameState):
        """
        Returns the expectimax + minimax action using self.depth and self.evaluationFunction

        All ghosts should be modeled as choosing uniformly at random from their
        legal moves.
        """
        "*** YOUR CODE HERE ***"

        def probabilityValue(state, depth, agentIndex):  # GHOSTS FUNCTION ESPECTIMAX
            "Primero, definimos el número de agentes de la funcion, que serán fantasmas"
            agentCount = gameState.getNumAgents()

            "Además, también conseguiremos su lista de acciones legales (lista de tipo N,S,E,O)"
            legalActions = state.getLegalActions(agentIndex)

            '''
            Antes de profundizar en la función probabilityValue, haremos 2 comprobaciones. Primero, comprobaremos que
            la lista de acciones legales no esté vacía. Luego miraremos si hemos perdido el juego según su estado.
            En el caso de que alguna sea cierta o las 2, retornaremos la evalución del estado.
            '''
            if legalActions == [] or gameState.isLose():
                return self.evaluationFunction(state)

            '''
            Como estamos jugando con probabilidades, de forma trivial, sabiendo que tenemos n acciones legales,
            nuestra probabilidad de escoger alguna de dichas acciones es 1/numero de acciones legales disponibles.
            '''
            probability = 1.0 / len(legalActions)

            "Inicializaremos el valor de espectimax que buscamos"
            espectimaxValue = 0

            "Por cada accion legal de los fantasmas"
            for legalAction in legalActions:
                # Mientras queden fantasmas, es decir, mientras no sea el turno del pacman
                if agentIndex != agentCount - 1:
                    # Llamaremos a probabilityValue para quedarnos con el valor de espectimax de la acción actual
                    currentExpectimaxValue = probabilityValue(state.generateSuccessor(agentIndex, legalAction), depth,
                                                              agentIndex + 1)
                else:
                    # En este caso, ya no quedan fantasmas y le toca al Pacman. Al Pacman le interesa maximizar sus
                    # ganancias, por ello llamaremos a maxValue_expectimax con la accion legal actual
                    currentExpectimaxValue = maxValue_expectimaxMinimax(state.generateSuccessor(agentIndex, legalAction),
                                                                 depth, 0)

                # El valor resultante será la muliplicación del valor calculado por la probabilidad de que escoja
                # esa accion el fantasma
                espectimaxValue += currentExpectimaxValue * probability

            "Una vez hechos todos los calculos en profundidad, retornaremos el valor resultante"
            return espectimaxValue

        def minValue(state, depth, agentIndex):  # GHOSTS FUNCTION MINIMAX
            "Primero, definimos el número de agentes de la funcion, que serán fantasmas"
            agentCount = gameState.getNumAgents()
            "Además, también conseguiremos su lista de acciones legales (lista de tipo N,S,E,O)"
            legalActions = state.getLegalActions(agentIndex)

            '''
            Antes de profundiar en la función minValue, haremos 2 comprobaciones. Primero, comprobaremos que la lista de 
            acciones legales no esté vacía. Luego miraremos si hemos perdido el juego según su estado.
            En el caso de que alguna sea cierta o las 2, retornaremos la evalución del estado.
            '''
            if legalActions == [] or gameState.isLose():
                return self.evaluationFunction(state)

            '''
            En el caso de que sigamos jugando, calcularemos la mejor jugada para cada fantasma del juego.
            Para ello, mientras queden fantasmas, es decir, mientras no sea el turno del pacman   
            '''
            if agentIndex != agentCount - 1:
                # Por cada accion legal de los fantasmas, llamaremos recursivamente a minValue hasta quedarnos con el
                # minimo valor de todos los posibles, ya que esta es la jugada que favorecerá más a los fantasmas.
                minimumValue = min(
                    minValue(state.generateSuccessor(agentIndex, legalAction), depth, agentIndex + 1) for legalAction in
                    legalActions)

            else:
                # En este caso, ya no quedan fantasmas y le toca al Pacman. Al Pacman le interesa maximizar sus ganancias,
                # por ello llamaremos recursivamente a maxValue por cada accion legal que puedan hacer los fantasmas.
                # Como, de todas las posibles jugadas del Pacman, a los fantasmas les interesa la que minimice sus
                # ganancias, pillaremos el minimo valor posible de las jugadas del Pacman ante las acciones de los fantasmas.
                minimumValue = min(
                    maxValue_expectimaxMinimax(state.generateSuccessor(agentIndex, legalAction), depth, 0) for legalAction in
                    legalActions)

            "Una vez hechos todos los calculos en profundidad, retornaremos la mejor accion para los fantasmas"
            return minimumValue

        def minValue_expextimaxMinimax(state, depth, agentIndex, k):
            "Primero, definimos el número de agentes de la funcion, que serán fantasmas"
            agentCount = gameState.getNumAgents()

            "Además, también conseguiremos su lista de acciones legales (lista de tipo N,S,E,O)"
            legalActions = state.getLegalActions(agentIndex)

            '''
            Antes de profundiar en la función minValue_expextimaxMinimax, haremos 2 comprobaciones. Primero,
            comprobaremos que la lista de acciones legales no esté vacía. Luego miraremos si hemos perdido el juego
            según su estado. En el caso de que alguna sea cierta o las 2, retornaremos la evalución del estado.
            '''
            if legalActions == [] or gameState.isLose():
                return self.evaluationFunction(state)

            '''
            En el caso de que sigamos jugando, calcularemos la mejor jugada para cada fantasma del juego.
            Para ello, mientras queden fantasmas, es decir, mientras no sea el turno del pacman   
            '''
            if agentIndex != agentCount - 1:
                # En este caso, definiremos los valores minimos de cada version de funciones para fantasmas. Por ello,
                # tendremos que el valor resultante estará basado en Minimax y Espectimax.
                valor_minimax = min(minValue(state.generateSuccessor(agentIndex, legalAction), depth, agentIndex + 1)
                                    for legalAction in legalActions)
                valor_espectimax = min(probabilityValue(state.generateSuccessor(agentIndex, legalAction), depth,
                                                        agentIndex + 1) for legalAction in legalActions)

            else:
                # En este caso, ya no quedan fantasmas y le toca al Pacman. Al Pacman le interesa maximizar sus
                # ganancias, y ambos metodos siguen la misma tecnica en las fucniones maximizadoras. Por ende seran
                # lo mismo.
                valor_minimax = min(maxValue_expectimaxMinimax(state.generateSuccessor(agentIndex, legalAction), depth, 0)
                                    for legalAction in legalActions)
                valor_espectimax = min(maxValue_expectimaxMinimax(state.generateSuccessor(agentIndex, legalAction), depth, 0)
                                    for legalAction in legalActions)

            "Una vez tengamos ambos valores (minValue de Minimax y minValue de Espectimax, calculamos el valor real"
            minimumValue = k * valor_minimax + (1 - k) * valor_espectimax

            "Retornaremos la mejor accion para los fantasmas"
            return minimumValue

        def maxValue_expectimaxMinimax(state, depth, agentIndex):
            """
            Como en este caso nuestro agente es el Pacman y solo hay uno, no necesitamos saber el numero de agentes
            Sin embargo, sí queremos conocer su listado de acciones legales
            """
            legalActions = state.getLegalActions(agentIndex)

            "También definimos el valor maximo como -infinito"
            maximumValue = - float("inf")

            '''
            Antes de profundiar en la función maxValue_expectimaxMinimax, haremos comprobaciones. Primero, comprobaremos 
            que la lista de acciones legales no esté vacía. Luego miraremos si hemos alcanzado la profundidad maxima o
            si hemos ganado el juego según su estado. En el caso de que alguna sea cierta, retornaremos la evalución del
            estado.
            '''
            if legalActions == [] or depth == self.depth or gameState.isWin():
                return self.evaluationFunction(state)

            '''
            A nuestro Pacman lo que le interesa es maximizar sus ganancias respecto a los fantasmas, por lo que por
            cada accion legal posible que tenga, comprobará que le interesa más entre las jugadas de los fantasmas en 
            esos casos y su valor maximo actual. De todas estas posibilidades, escogerá la que mayor beneficio le traiga.
            '''
            """
            Como probabilityValue de Espectimax y maxValue de Minimax hacen el mismo conjunto de operaciones y
            comprobaciones, obtendremos el mismo resultando llamando a una u otra.
            """
            for legalAction in legalActions:
                maximumValue = max(maximumValue, probabilityValue(state.generateSuccessor(agentIndex, legalAction),
                                                                  depth + 1, agentIndex + 1))

            "Una vez conseguida la mejor jugada del Pacman para este estado, retornaremos dicho valor"
            return maximumValue

        def espectimaxMinimax(state, depth, agentIndex, k):
            "Primero definimos la mejor evaluación y la mejor accion"
            bestActionEval, bestAction = - float("inf"), None

            "Luego, conseguimos la lista de acciones legales del agente"
            legalActions = state.getLegalActions(agentIndex)

            "Por cada accion legal del agente"
            for legalAction in legalActions:
                # Evaluaremos cual será la mejor jugada de su openente respecto a esta accion
                evalAction = minValue_expextimaxMinimax(gameState.generateSuccessor(agentIndex, legalAction), depth,
                                              agentIndex + 1, k)

                # Si la jugada evaluada actualmente es mejor que la mejor evaluacion registrada
                if evalAction > bestActionEval:
                    # Actualizaremos la mejor evaluación y la mejor jugada por las actuales
                    bestAction = legalAction
                    bestActionEval = evalAction

            "Una vez llegado el final del juego, retornaremos la mejor accion"
            return bestAction

        "Como empezará a moverse el Pacman, asignaremos el index del agente a 0"
        agentIndex = 0

        "Inicializamos la constante K, que será un valor entre 0 y 1, y la profundidad"
        kParam, depth = self.kParam, self.depth
        return espectimaxMinimax(gameState, depth, agentIndex, kParam)


# Abbreviation
better = betterEvaluationFunction
